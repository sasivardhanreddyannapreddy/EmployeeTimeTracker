package com.timetracker.model;

public enum Role {
    ASSOCIATE,
    ADMIN,
    EMPLOYEE;
}